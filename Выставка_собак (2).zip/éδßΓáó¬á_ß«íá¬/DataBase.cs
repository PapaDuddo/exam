﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Выставка_собак
{
    internal class DataBase
    {
        SqlConnection SqlConnection = new SqlConnection(@"Data Source=0_311_10;Initial Catalog=Выставка_собак;Integrated Security=True");

//        public void OpenConnection
//        {
//            if(SqlConnectionState==System.Data.ConnectionState closed)
//            {
//            SqlConnection.Open
//}

        }
    
}
